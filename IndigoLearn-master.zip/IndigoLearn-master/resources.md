# Styled Components

## Custom Button Styles

```
  padding: 10px;
  margin-right: 20px;
  font-size: 15px;
  color: #ffffff;
  border-radius: 4px;
  border: 2px solid #0070c1;
  background-color: #0070c1;
```

## Outline Button Styles

```
  padding: 10px;
  margin-right: 20px;
  font-size: 15px;
  color: #0070c1;
  border-radius: 4px;
  border: 2px solid #0070c1;
  background-color: #ffffff;
```
