# Styled Components

- Styling React Components
  - CSS-in-JS
- Styled Components
  - Adapting based on props
  - Conditional Styling
- Advantages
  - Unique Class Names
  - Readability
